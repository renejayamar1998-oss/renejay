"""Render restrained word-by-word captions from word timestamps.

Input JSON may be either a list of {start, end, text} words or an object
with a `words` list. Timestamps are seconds on the target video's timeline.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import tempfile
from pathlib import Path

from _bin import find


def ass_time(seconds: float) -> str:
    centiseconds = max(0, round(seconds * 100))
    hours, centiseconds = divmod(centiseconds, 360000)
    minutes, centiseconds = divmod(centiseconds, 6000)
    whole_seconds, centiseconds = divmod(centiseconds, 100)
    return f"{hours}:{minutes:02d}:{whole_seconds:02d}.{centiseconds:02d}"


def load_words(path: Path) -> list[dict]:
    data = json.loads(path.read_text(encoding="utf-8"))
    words = data if isinstance(data, list) else data.get("words", [])
    normalized = []
    for word in words:
        text = str(word.get("text", "")).strip()
        start, end = float(word["start"]), float(word["end"])
        if text and end > start >= 0:
            normalized.append({"start": start, "end": end, "text": text})
    normalized.sort(key=lambda item: (item["start"], item["end"]))
    if not normalized:
        raise ValueError("Walang valid na word timestamps sa caption JSON.")
    return normalized


def ass_escape(text: str) -> str:
    return text.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}")


def make_ass(words: list[dict], width: int, height: int, output: Path) -> None:
    # Keep the highlighted word centered in a compact phrase so captions stay
    # within the safe width of portrait and landscape videos.
    events = []
    for index, active in enumerate(words):
        left = right = index
        # About 25 average-width uppercase characters fit comfortably at the
        # selected font size with the existing side margins.
        max_chars = 25
        while True:
            candidates = []
            if left > 0 and index - left < 2 and words[left]["start"] - words[left - 1]["end"] <= 0.35:
                candidates.append((left - 1, right))
            if right + 1 < len(words) and right - index < 2 and words[right + 1]["start"] - words[right]["end"] <= 0.35:
                candidates.append((left, right + 1))
            fitting = [bounds for bounds in candidates if sum(
                len(words[cursor]["text"].strip()) + (1 if cursor > bounds[0] else 0)
                for cursor in range(bounds[0], bounds[1] + 1)
            ) <= max_chars]
            if not fitting:
                break
            left, right = min(fitting, key=lambda bounds: (abs((index - bounds[0]) - (bounds[1] - index)), bounds[0]))
        phrase = []
        for cursor in range(left, right + 1):
            token = ass_escape(words[cursor]["text"]).upper()
            if cursor == index:
                phrase.append(r"{\c&H0054D8FF&}" + token + r"{\c&H00FFFFFF&}")
            else:
                phrase.append(token)
        text = " ".join(phrase)
        events.append(
            f"Dialogue: 0,{ass_time(active['start'])},{ass_time(active['end'])},Caption,,0,0,0,,{text}"
        )

    header = f"""[Script Info]
Title: Editor Calm Word Captions
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Caption,Arial,32,&H00FFFFFF,&H0054D8FF,&HCC000000,&H66000000,-1,0,0,0,100,100,0,0,1,3,0.8,2,42,42,120,1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
"""
    output.write_text(header + "\n".join(events) + "\n", encoding="utf-8-sig")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("video", type=Path, help="Video na lalagyan ng captions")
    parser.add_argument("words_json", type=Path, help="Word timestamps sa JSON, segundo sa video timeline")
    parser.add_argument("output", type=Path, help="Output MP4")
    parser.add_argument("--ass", type=Path, help="Opsyonal na kopya ng generated ASS subtitle file")
    args = parser.parse_args()

    words = load_words(args.words_json)
    probe = json.loads(subprocess.check_output([
        find("ffprobe"), "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height", "-of", "json", str(args.video),
    ], text=True))
    width, height = probe["streams"][0]["width"], probe["streams"][0]["height"]
    args.output.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="editor_captions_") as temporary:
        ass_path = Path(temporary) / "captions.ass"
        make_ass(words, width, height, ass_path)
        if args.ass:
            args.ass.parent.mkdir(parents=True, exist_ok=True)
            args.ass.write_bytes(ass_path.read_bytes())
        # FFmpeg's subtitles filter handles the subtitle file as a filter input.
        subtitle_arg = str(ass_path).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")
        subprocess.run([
            find("ffmpeg"), "-y", "-i", str(args.video), "-vf", f"subtitles='{subtitle_arg}'",
            "-c:v", "libx264", "-crf", "18", "-preset", "medium", "-c:a", "copy",
            str(args.output),
        ], check=True)
    print(f"Nailagay ang captions: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
