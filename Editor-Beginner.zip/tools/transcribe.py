"""Create word-level timestamps for a video using the locally installed Whisper model."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import tempfile
from pathlib import Path

import numpy as np
from faster_whisper import WhisperModel

from _bin import find


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("video", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--model", default=os.environ.get("EDITOR_WHISPER_MODEL", "base.en"))
    parser.add_argument("--language", default=os.environ.get("EDITOR_CAPTION_LANGUAGE"),
                        help="Optional language code, e.g. en, tl, or ja. Default: detect.")
    args = parser.parse_args()

    cache = Path(os.environ.get("USERPROFILE", str(Path.home()))) / ".cache" / "huggingface" / "hub"
    model_dir = cache / f"models--Systran--faster-whisper-{args.model}" / "snapshots"
    local_snapshots = sorted(model_dir.iterdir()) if model_dir.is_dir() else []
    model_source = str(local_snapshots[-1]) if local_snapshots else args.model
    model = WhisperModel(model_source, device="cpu", compute_type="int8",
                         cpu_threads=max(1, min(8, os.cpu_count() or 4)),
                         local_files_only=bool(local_snapshots))

    extracted = subprocess.run([
        find("ffmpeg"), "-hide_banner", "-loglevel", "error", "-i", str(args.video),
        "-vn", "-ac", "1", "-ar", "16000", "-f", "f32le", "pipe:1",
    ], check=True, capture_output=True).stdout
    audio = np.frombuffer(extracted, dtype=np.float32)
    if audio.size == 0:
        raise RuntimeError("Walang audio track ang video; hindi makakagawa ng captions.")

    segments, info = model.transcribe(audio, beam_size=5, word_timestamps=True, vad_filter=True,
                                     language=args.language or None,
                                     vad_parameters={"min_silence_duration_ms": 250})
    words = []
    for segment in segments:
        for word in segment.words or []:
            token = word.word.strip()
            start, end = max(0.0, float(word.start)), float(word.end)
            if token and end > start:
                words.append({"start": round(start, 3), "end": round(end, 3), "text": token})
    if not words:
        raise RuntimeError("Walang na-detect na salita. Hindi gagawa ng walang-lamang caption file.")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({"language": info.language, "duration": info.duration,
                                       "words": words}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Detected language: {info.language}; {len(words)} words; saved {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
