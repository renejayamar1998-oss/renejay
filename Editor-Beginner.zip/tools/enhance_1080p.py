"""Upscale a video to a 1080p canvas with high-quality FFmpeg scaling.

Portrait inputs become 1080x1920; landscape inputs become 1920x1080.
Aspect ratio is preserved and any unused canvas area is filled with black.
"""
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

from _bin import find


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("video", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    probe = json.loads(subprocess.check_output([
        find("ffprobe"), "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height", "-of", "json", str(args.video),
    ], text=True))
    stream = probe["streams"][0]
    width, height = int(stream["width"]), int(stream["height"])
    target_w, target_h = (1920, 1080) if width >= height else (1080, 1920)
    vf = (f"scale={target_w}:{target_h}:force_original_aspect_ratio=decrease:"
          f"force_divisible_by=2:flags=lanczos,"
          f"pad={target_w}:{target_h}:(ow-iw)/2:(oh-ih)/2:color=black,"
          "setsar=1,unsharp=5:5:0.35:3:3:0")
    subprocess.run([
        find("ffmpeg"), "-hide_banner", "-y", "-i", str(args.video),
        "-vf", vf, "-c:v", "libx264", "-crf", "18", "-preset", "medium",
        "-pix_fmt", "yuv420p", "-c:a", "copy", "-movflags", "+faststart",
        str(args.output),
    ], check=True)
    print(f"Na-enhance sa {target_w}x{target_h}: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
