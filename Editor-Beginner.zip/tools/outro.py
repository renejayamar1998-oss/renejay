"""Append a five-second cinematic next-episode subscribe outro."""
from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path

from _bin import find

FPS = 30
DURATION = 5


def probe(path: Path) -> dict:
    return json.loads(subprocess.check_output([
        find("ffprobe"), "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path),
    ], text=True))


def ff_path(path: Path) -> str:
    return str(path.resolve()).replace("\\", "/").replace(":", r"\:").replace("'", r"\'")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("video", type=Path, help="Edited episode video")
    parser.add_argument("output", type=Path, help="Episode with the outro appended")
    args = parser.parse_args()
    source_probe = probe(args.video)
    streams = source_probe["streams"]
    video = next(stream for stream in streams if stream["codec_type"] == "video")
    width, height = int(video["width"]), int(video["height"])
    has_audio = any(stream["codec_type"] == "audio" for stream in streams)
    source_duration = float(source_probe["format"]["duration"])
    poster = args.output.with_suffix(".outro-frame.png")
    subprocess.run([
        find("ffmpeg"), "-hide_banner", "-y", "-sseof", "-0.08", "-i", str(args.video),
        "-frames:v", "1", str(poster),
    ], check=True)

    font = ff_path(Path("C:/Windows/Fonts/arial.ttf"))
    # Keep the typography restrained and centered in both portrait and landscape formats.
    first_text = args.output.with_suffix(".outro-first.txt")
    second_text = args.output.with_suffix(".outro-second.txt")
    button_text = args.output.with_suffix(".outro-button.txt")
    first_text.write_text("THE STORY ISN'T OVER YET...", encoding="utf-8")
    second_text.write_text("SUBSCRIBE FOR THE NEXT EPISODE!", encoding="utf-8")
    button_text.write_text("SUBSCRIBE", encoding="utf-8")
    title_size = max(34, min(width, height) // 23)
    subscribe_size = max(30, min(width, height) // 28)
    button_size = max(24, min(width, height) // 38)
    title_y = int(height * 0.43)
    subscribe_y = int(height * 0.52)
    button_y = int(height * 0.67)
    fade_in = "if(lt(t,0.5),0,if(lt(t,0.9),(t-0.5)/0.4,1))"
    title_alpha = f"{fade_in}*if(lt(t,2.7),1,if(lt(t,3.0),(3.0-t)/0.3,0))"
    sub_alpha = f"if(lt(t,2.55),0,if(lt(t,2.95),(t-2.55)/0.4,1))"
    line_width = f"min({int(width * 0.42)},max(0,(t-2.85)*{int(width * 0.8)}))"
    vf = (
        f"zoompan=z='min(zoom+0.00012,1.025)':x='iw/2-(iw/zoom/2)':"
        f"y='ih/2-(ih/zoom/2)':d={FPS * DURATION}:s={width}x{height}:fps={FPS},"
        "eq=brightness=-0.16:saturation=0.78,vignette=PI/5,"
        f"drawtext=fontfile='{font}':textfile='{ff_path(first_text)}':"
        f"fontsize={title_size}:fontcolor=0xF3E6CC:borderw=2:bordercolor=black@0.45:"
        f"x=(w-text_w)/2:y={title_y}-text_h/2:alpha='{title_alpha}',"
        f"drawbox=x=(w-{int(width * 0.46)})/2:y={int(height * 0.485)}:"
        f"w='{line_width}':h=2:color=0xD5B77A@0.85:t=fill:enable='between(t,2.85,4.4)',"
        f"drawtext=fontfile='{font}':textfile='{ff_path(second_text)}':"
        f"fontsize={subscribe_size}:fontcolor=white:borderw=2:bordercolor=black@0.5:"
        f"x=(w-text_w)/2:y={subscribe_y}-text_h/2:alpha='{sub_alpha}',"
        f"drawbox=x=(w-{int(width * 0.34)})/2:y={button_y-int(height * 0.03)}:"
        f"w={int(width * 0.34)}:h={int(height * 0.06)}:color=0xD5B77A@0.12:"
        "t=fill:enable='between(t,3.0,5)',"
        f"drawbox=x=(w-{int(width * 0.34)})/2:y={button_y-int(height * 0.03)}:"
        f"w={int(width * 0.34)}:h={int(height * 0.06)}:color=0xD5B77A@0.8:"
        "t=2:enable='between(t,3.0,5)',"
        f"drawtext=fontfile='{font}':textfile='{ff_path(button_text)}':"
        f"fontsize={button_size}:fontcolor=0xF3E6CC:x=(w-text_w)/2:"
        f"y={button_y}-text_h/2:alpha='{sub_alpha}'"
    )

    cmd = [find("ffmpeg"), "-hide_banner", "-y", "-loop", "1", "-framerate", str(FPS),
           "-i", str(poster), "-f", "lavfi", "-i", f"sine=frequency=130.81:duration={DURATION}:sample_rate=48000",
           "-f", "lavfi", "-i", f"sine=frequency=155.56:duration={DURATION}:sample_rate=48000",
           "-f", "lavfi", "-i", f"sine=frequency=196:duration={DURATION}:sample_rate=48000",
           "-t", str(DURATION), "-vf", vf,
           "-filter_complex",
           "[1:a]volume=0.035[a1];[2:a]volume=0.028[a2];[3:a]volume=0.02[a3];"
           "[a1][a2][a3]amix=inputs=3:normalize=0,lowpass=f=900,"
           "aecho=0.8:0.7:70:0.25,volume=0.65,afade=t=in:st=0:d=0.8,"
           "afade=t=out:st=3.8:d=1.2,apad=whole_dur=5,atrim=duration=5[a]",
           "-map", "0:v", "-map", "[a]", "-r", str(FPS), "-frames:v", str(FPS * DURATION),
           "-c:v", "libx264", "-crf", "18", "-preset", "medium", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "128k", "-t", str(DURATION), str(args.output)]
    outro_clip = args.output.with_suffix(".outro.mp4")
    subprocess.run(cmd[:-1] + [str(outro_clip)], check=True)

    concat_args = [find("ffmpeg"), "-hide_banner", "-y", "-i", str(args.video),
                   "-i", str(outro_clip)]
    if has_audio:
        graph = ("[0:a:0]aresample=48000,aformat=channel_layouts=stereo[a0];"
                 "[1:a:0]aresample=48000,aformat=channel_layouts=stereo[a1];"
                 "[0:v:0][a0][1:v:0][a1]concat=n=2:v=1:a=1[v][a]")
    else:
        concat_args += ["-f", "lavfi", "-t", str(source_duration), "-i",
                        "anullsrc=channel_layout=stereo:sample_rate=48000"]
        graph = "[0:v:0][2:a:0][1:v:0][1:a:0]concat=n=2:v=1:a=1[v][a]"
    concat_args += ["-filter_complex", graph, "-map", "[v]", "-map", "[a]",
                    "-c:v", "libx264", "-crf", "18", "-preset", "medium",
                    "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
                    "-movflags", "+faststart", str(args.output)]
    subprocess.run(concat_args, check=True)
    poster.unlink(missing_ok=True)
    first_text.unlink(missing_ok=True)
    second_text.unlink(missing_ok=True)
    button_text.unlink(missing_ok=True)
    outro_clip.unlink(missing_ok=True)
    print(f"Naidagdag ang 5-second outro: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
