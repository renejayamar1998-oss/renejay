VISUAL TRANSITIONS

Choose at most one visual transition for a clip boundary. Do not stack two styles at the same cut or repeat a flashy effect across neighboring cuts unless the story calls for it. Use a clean hard cut when an effect adds no story meaning. Match the transition to the scene and keep dialogue and faces clear.

1. Cross dissolve (0.5–1 s) — emotional scenes, flashbacks, or a shift in feeling.
2. Dip to black — end of a scene, death, grief, or a major reveal.
3. Fade in / fade out — beginning or end of an episode.
4. Hard cut (includes jump cut) — fights, shouting, and tension; quick and sharp.
5. Match cut — connect similar movement or shape between shots, such as hand-to-hand or eye-to-eye.
6. Dip to white — flashback, memory, or dream.
7. Slow zoom in — build tension before a major line or confession; this is a lead-in to the cut, not a second transition at the boundary.
8. Whip pan (swipe) — move to another place or character during tension.
9. Flash cut / quick flash — shock, slap, or plot-twist reveal.
10. Cliffhanger cut to black — the final moment of a 60-second episode. This is a story-specific use of dip/cut to black, not an extra effect to stack on top.

Some listed transitions are editorial guidance and are not yet rendered by the current join tool. Current generated visual transitions are hard cut, zoom, flash, and dip to black. Match cuts, reaction timing, and J-cuts are made through shot selection and editing timing.

AUDIO IS SEPARATE

Put transition sound files only in Transition Sound Effect/. The sound begins 3 frames (within the requested 2–5 frames) before the visual cut. Do not place audio files in this visual folder.
