Dito malilikha ang natapos na video pagkatapos patakbuhin ang editor.
