"""Automatically edit every supported video in INPUT and save one final video in OUTPUT.

Run with: .venv\\Scripts\\python.exe auto_edit.py
Optional assets are used only when present: MB music and an image in IMAGES.
"""
from __future__ import annotations

import json
import argparse
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "INPUT"
OUTPUT = ROOT / "OUTPUT"
WORK = ROOT / "work"
VIDEO_EXT = {".mp4", ".mov", ".mkv", ".m4v", ".avi", ".webm"}
AUDIO_EXT = {".mp3", ".wav", ".m4a", ".flac", ".ogg", ".aac"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}


def natural_key(path: Path):
    import re
    return [int(x) if x.isdigit() else x.lower()
            for x in re.split(r"(\d+)", path.name)]


def run(args: list[str]) -> None:
    print("\n>", " ".join(str(x) for x in args), flush=True)
    subprocess.run([str(x) for x in args], cwd=ROOT, check=True)


MUSIC_PRESETS = {
    "dramatic background": {"aliases": {"dramatic background", "dramatic", "english"},
                            "filename": "Dramatic Background.MP3", "language": "en", "model": "base.en"},
    "sanctus": {"aliases": {"sanctus", "tagalog"}, "filename": "Sanctus.mp3",
                "language": "tl", "model": "base"},
}


def choose_music(value: str | None, tracks: list[Path]) -> tuple[Path, dict] | None:
    if not tracks:
        return None
    if value is None:
        print("Pumili ng background music / caption language:")
        print("  1) Sanctus — Tagalog")
        print("  2) Dramatic Background — English")
        if not sys.stdin.isatty():
            raise ValueError("Pumili gamit ang --music sanctus o --music dramatic-background.")
        value = input("Ilagay ang 1 o 2: ").strip()
        value = {"1": "sanctus", "2": "dramatic background"}.get(value, value)

    normalized = " ".join(value.casefold().replace("-", " ").split())
    preset = next((entry for entry in MUSIC_PRESETS.values() if normalized in entry["aliases"]), None)
    if preset is None:
        raise ValueError("Hindi kilalang pagpipilian. Gamitin ang Sanctus/Tagalog o Dramatic Background/English.")
    track = next((item for item in tracks if item.name.casefold() == preset["filename"].casefold()), None)
    if track is None:
        raise ValueError(f"Hindi makita ang napiling music file sa MB/: {preset['filename']}")
    return track, preset


def main() -> int:
    parser = argparse.ArgumentParser(description="Awtomatikong mag-edit ng mga video sa INPUT/.")
    parser.add_argument("--music", help="Piliin: sanctus/tagalog o dramatic-background/english")
    options = parser.parse_args()

    clips = sorted((p for p in INPUT.iterdir() if p.is_file() and p.suffix.lower() in VIDEO_EXT),
                   key=natural_key) if INPUT.is_dir() else []
    if not clips:
        print(f"Walang video sa {INPUT}. Maglagay ng MP4/MOV/MKV at iba pa sa INPUT folder.", file=sys.stderr)
        return 2

    music_files = sorted((p for p in (ROOT / "MB").iterdir()
                          if p.is_file() and p.suffix.lower() in AUDIO_EXT), key=natural_key)
    selection = choose_music(options.music, music_files)
    if options.music and not selection:
        raise ValueError("Walang music files sa MB/ para sa napili mong track.")
    music, music_preset = ([selection[0]], selection[1]) if selection else ([], None)

    OUTPUT.mkdir(exist_ok=True)
    WORK.mkdir(exist_ok=True)
    final = OUTPUT / "final-auto-edit.mp4"
    with tempfile.TemporaryDirectory(prefix="auto_edit_", dir=WORK) as tmp_name:
        tmp = Path(tmp_name)
        joined, graded, zoomed = tmp / "joined.mp4", tmp / "graded.mp4", tmp / "zoomed.mp4"

        # Trim quiet gaps in each scene, join in filename order, and add restrained transitions
        # with the supplied transition sounds when available.
        run([sys.executable, ROOT / "tools" / "join_clips.py", "render", joined,
             "--folder", INPUT, "--transition", "mix", "--trim",
             "--transition-sfx-dir", ROOT / "Transition Sound Effect"])

        # Apply a restrained cinematic grade and a subtle, slow push-in across the final cut.
        run([sys.executable, ROOT / "tools" / "grade.py", "render", joined, graded,
             "--preset", "cinematic"])
        probe = subprocess.run([
            sys.executable, "-c",
            "import json,subprocess,sys; from tools._bin import find; "
            "j=json.loads(subprocess.check_output([find('ffprobe'),'-v','error','-show_entries',"
            "'format=duration','-of','json',sys.argv[1]])); print(float(j['format']['duration']))",
            str(graded)], cwd=ROOT, check=True, capture_output=True, text=True)
        duration = float(probe.stdout.strip())
        spec = tmp / "zoom.json"
        spec.write_text(json.dumps({"center": [0.5, 0.42], "keys": [[0, 1.0], [duration, 1.04]]}),
                        encoding="utf-8")
        run([sys.executable, ROOT / "tools" / "zoom.py", "render", graded, zoomed, spec])
        # Speed the complete edit up slightly while preserving the original pitch.
        from tools._bin import find
        sped = tmp / "sped.mp4"
        subprocess.run([find("ffmpeg"), "-hide_banner", "-y", "-i", str(zoomed),
                        "-vf", "setpts=PTS/1.05", "-af", "atempo=1.05",
                        "-c:v", "libx264", "-crf", "17", "-preset", "medium",
                        "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
                        "-movflags", "+faststart", str(sped)], check=True)
        current = sped

        if music:
            mixed = tmp / "music.mp4"
            run([sys.executable, ROOT / "tools" / "music.py", "render", current, mixed,
                 "--track", music[0].name, "--duck-ratio", "2", "--level", "-8"])
            current = mixed

        images = sorted((p for p in (ROOT / "IMAGES").iterdir()
                         if p.is_file() and p.suffix.lower() in IMAGE_EXT), key=natural_key)
        if images:
            branded = tmp / "branded.mp4"
            run([sys.executable, ROOT / "tools" / "images.py", "render", current, branded,
                 "--image", images[0].name])
            current = branded

        # Transcribe the finished timeline and burn word-timed captions into the final render.
        words_json, captioned = tmp / "word-timestamps.json", tmp / "captioned.mp4"
        transcript_args = [sys.executable, ROOT / "tools" / "transcribe.py", current, words_json]
        if music_preset:
            model = os.environ.get("EDITOR_WHISPER_MODEL", music_preset["model"])
            if music_preset["language"] == "tl" and model.endswith(".en"):
                model = music_preset["model"]
            transcript_args += ["--language", music_preset["language"], "--model", model]
        run(transcript_args)
        captions_ass = OUTPUT / "final-auto-edit-captions.ass"
        run([sys.executable, ROOT / "tools" / "captions.py", current, words_json, captioned,
             "--ass", captions_ass])
        enhanced = tmp / "enhanced-1080p.mp4"
        run([sys.executable, ROOT / "tools" / "enhance_1080p.py", captioned, enhanced])
        episode_outro = tmp / "episode-with-outro.mp4"
        run([sys.executable, ROOT / "tools" / "outro.py", enhanced, episode_outro])
        current = episode_outro

        # Replace only the generated final output; source clips stay untouched.
        if final.exists():
            final.unlink()
        current.replace(final)

    report = {
        "output": str(final),
        "inputs": [p.name for p in clips],
        "steps": ["trim dead air", "join scenes", "alternating zoom/flash transitions",
                  "transition sound effects", "cinematic color grade", "subtle smart zoom",
                  "automatic speech transcription", "word-by-word captions",
                  "1080p upscale and light sharpening", "5-second cinematic subscribe outro"],
        "optional_assets": {"music": music[0].name if music else None,
                            "image_overlay": bool(images)},
        "caption_language": music_preset["language"] if music_preset else None,
    }
    (OUTPUT / "final-auto-edit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"\nTapos na. Video: {final}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except ValueError as exc:
        print(f"Hindi maituloy ang Editor: {exc}", file=sys.stderr)
        raise SystemExit(2)
    except subprocess.CalledProcessError as exc:
        print(f"Nagkaproblema sa edit step (exit code {exc.returncode}). Tingnan ang mensahe sa itaas.",
              file=sys.stderr)
        raise SystemExit(exc.returncode or 1)
