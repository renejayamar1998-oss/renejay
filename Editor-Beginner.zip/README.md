# Editor

**An AI video editor skill for [Claude Code](https://claude.com/claude-code), by Doji Creates.**

Drop your raw clips into `INPUT/`, call the skill, and get one finished short-form video in `OUTPUT/`: joined, trimmed, colour graded, with sound effects, music and your logo.

Built for short vertical talking-head videos (Reels, TikTok, Shorts), but every step works on any video. Everything runs on your own computer. Nothing is uploaded.

## What it does (9 skills)

| # | Skill | What it does |
|---|-------|--------------|
| 1 | **Dead Air Removal** | Cuts longer, near-silent gaps while preserving quiet speech and a short margin around cuts. |
| 2 | **Morphing Shapes** | Charts and shape animations, plus animated like and subscribe buttons. |
| 3 | **Sound Effects** | Gentle synthesised SFX matched to the shapes (no music). |
| 4 | **Background Music** | Music from your `MB/` folder, levelled against the voice. |
| 5 | **Logos & Images** | Places your logo (or any picture) from `IMAGES/`, background removed automatically. |
| 6 | **Color Grading** | Scene-matched presets for romance, suspense, betrayal, flashbacks, and more. |
| 7 | **Smart Zoom** | Slow, gentle zooms, plus an optional fast punch-in with a slow zoom out. |
| 8 | **Clip Joining** | If `INPUT/` has `CLIP 1`, `CLIP 2`, ... they are joined first, in order. |
| 9 | **Transitions** | Zoom-through, flash or dip between clips, with your transition sounds if provided. |

### Cinematic transition direction

Match one visual transition to each clip boundary, following the single canonical list in `Transition Effects/README.md`. Do not stack or duplicate transition styles on the same cut. The current clip-joining tool renders hard cuts, zoom, flash, and dip-to-black; other listed looks guide shot selection and can be added to the renderer later.

### Color grading by scene

The editor includes separate looks for warm golden romance, cold blue isolation, teal-and-orange drama, dark desaturated revenge, soft pastel romance, luxury amber interiors, muted green suspense, warm faded flashbacks, cool silver offices, and high-contrast neutral confrontations. Choose one grade that fits each scene; do not stack or apply every look to the whole video. Preserve natural skin tones and facial detail.

Preset IDs: `warm-golden`, `cold-blue`, `teal-orange`, `dark-desaturated`, `soft-pastel`, `luxury-amber`, `muted-green`, `warm-faded`, `cool-silver`, and `high-contrast-neutral`.

## Requirements

- [Claude Code](https://claude.com/claude-code)
- Python 3.10+ and Node.js 18+
- FFmpeg **7 or newer** (with ffprobe). The Windows setup script can download a portable copy.
- Built and tested on Windows. macOS and Linux should work (the font `Arial Black` must be installed for the text styles).
- Optional: an NVIDIA GPU makes transcription faster. CPU works too.

## Install

Download this repository (green **Code** button, then **Download ZIP**) or clone it, then run the setup once.

Windows (PowerShell):

```powershell
.\setup.ps1
```

macOS / Linux:

```bash
bash setup.sh
```

This creates `.venv/`, installs the required Python packages and the Node packages (`hyperframes`, `gsap`).

## Use

1. Put the raw video you want edited, or numbered clips such as `CLIP 1.mp4`, `CLIP 2.mp4`, in `INPUT/`.
2. (Optional) Put background music in `MB/`, your logo in `IMAGES/`, visual transition guidance/assets in `Transition Effects/`, and transition sound effects in `Transition Sound Effect/`.
3. Open this project in Claude Code and run `/Editor`, or run the automatic editor from this folder:

   ```powershell
   .\.venv\Scripts\python.exe auto_edit.py
   ```

   It automatically trims quiet gaps, joins every video in filename order, adds alternating transitions and available transition sounds, applies a cinematic grade and gentle zoom, transcribes speech with the installed Faster Whisper model, burns word-by-word captions, then upscales and lightly sharpens the video to 1080p. It appends a five-second cinematic outro with “THE STORY ISN'T OVER YET...” and “SUBSCRIBE FOR THE NEXT EPISODE!”, a subtle animated subscribe button, and a soft synthesized music bed that fades out. Landscape output is 1920×1080; portrait output is 1080×1920. Aspect ratio is preserved, with black padding when needed. Source videos are never changed; intermediate files go to `work/`.

   Choose the music and caption language with `--music sanctus` (Tagalog) or `--music dramatic-background` (English). If omitted in an interactive terminal, the editor asks you to choose. The Tagalog selection uses Faster Whisper's multilingual `base` model; it may need to download on first use if it is not already cached.
4. Run the same command again whenever you add or replace clips in `INPUT/`. The generated final video is replaced on each run.

## Folders

```
Editor/
  .claude/skills/Editor/SKILL.md   the /Editor skill
  tools/                              the scripts behind each skill
  INPUT/    put the raw video/clips you want edited here (never modified)
  OUTPUT/   finished edited videos
  MB/       background music you may use
  IMAGES/   logos and pictures you may use
  Transition Effects/   visual transitions and guidance
  Transition Sound Effect/   your transition sounds (WAV, MP3, M4A, AAC, FLAC, OGG)
  work/     scratch files (created automatically, git-ignored)
  docs/     RECREATE_PROMPT.md, a full specification to rebuild this project from scratch
```

## Using the tools directly

Every script has a docstring and `--help`:

```bash
python tools/trim_dead_air.py INPUT/video.mp4 work/trimmed.mp4
python tools/grade.py presets
python tools/grade.py render INPUT/scene-1.mp4 work/scene-1-graded.mp4 --preset warm-golden
python tools/join_clips.py plan
python tools/enhance_1080p.py INPUT/scene.mp4 OUTPUT/scene-1080p.mp4
python tools/outro.py OUTPUT/scene-1080p.mp4 OUTPUT/scene-with-outro.mp4
```

### Word-by-word captions

`tools/captions.py` burns restrained, word-by-word captions into a video. It shows a short phrase for context and highlights only the spoken word in soft gold, with a bold white font and a modest dark outline. There is no bouncing or flashing animation.

Create a JSON file with word start/end timestamps in seconds on the target video's timeline:

```json
[
  { "start": 0.4, "end": 0.8, "text": "Akala" },
  { "start": 0.8, "end": 1.0, "text": "mo" },
  { "start": 1.0, "end": 1.5, "text": "hanggang" }
]
```

Then render the captioned video and optionally save the editable ASS subtitle file:

```powershell
.\.venv\Scripts\python.exe tools\captions.py OUTPUT\final-auto-edit.mp4 INPUT\word-timestamps.json OUTPUT\final-auto-edit-captioned.mp4 --ass OUTPUT\final-auto-edit-captions.ass
```

To add a like or subscribe animation, include an item like this in the morph JSON passed to `tools/morph.py`:

```json
[
  { "type": "like_button", "start": 3, "end": 5.5 },
  { "type": "subscribe_button", "start": 12, "end": 14.5, "text": "SUBSCRIBE" }
]
```

The like button defaults to blue and the subscribe button to red. You can set a different `text` or a `colors` list; leave at least 2.5 seconds for the tap and follow-up animation. Pass the same morph JSON to `tools/sfx.py --morph` to add its matching sound cues.

## Good to know

- **Music and images are yours to license.** None are included. Make sure you have the right to use what you put in `MB/` and `IMAGES/`, especially for commercial videos.
- **Visual transitions** are separate from audio; see `Transition Effects/` for the visual types and guidance. Add audio files to `Transition Sound Effect/`; name files `zoom`, `flash`, or `dip` to match a transition type, or use `transition`/`default` for one sound at every cut. Otherwise, files are assigned in sorted filename order. They start 3 frames before the cut; default gain is 1.0 and can be lowered with `--transition-sfx-gain` if needed.
- The skill cannot listen to audio. Check the volume of the sound effects and music yourself, and ask for them to be raised or lowered.
- Defaults are tuned for talking-head videos. Change them by asking, or edit the options in each script.

## Credits

Created by **Doji Creates**.

Built with [Claude Code](https://claude.com/claude-code) by Anthropic. It uses these open-source projects, each under its own licence:

- [FFmpeg](https://ffmpeg.org) for all video and audio processing
- [HyperFrames](https://github.com/heygen-com/hyperframes) (HeyGen) and [GSAP](https://gsap.com) for the morphing shapes
- [Pillow](https://python-pillow.org) and [NumPy](https://numpy.org) for image and sound processing

## License

[MIT](LICENSE) © 2026 Doji Creates
