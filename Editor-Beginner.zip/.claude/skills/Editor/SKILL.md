---
name: Editor
description: Automatically edit the videos in INPUT and save a captioned final video in OUTPUT.
---

# Editor

When the user invokes `/Editor` or asks to automatically edit the input videos, first ask which background music and caption language to use if they did not specify one:

- **Sanctus — Tagalog:** run with `--music sanctus`.
- **Dramatic Background — English:** run with `--music dramatic-background`.

Recognize `Tagalog` or `Sanctus` as the first choice, and `English` or `Dramatic Background` as the second choice. Do not start the render until the choice is clear. Run the pipeline from the Editor project root and pass the matching option:

```powershell
.\.venv\Scripts\python.exe auto_edit.py --music sanctus
```

The pipeline processes supported videos in `INPUT/` in natural filename order and saves the finished video to `OUTPUT/final-auto-edit.mp4`. It trims dead air, joins scenes with alternating zoom and flash transitions, uses transition sounds from `Transition Sound Effect/`, applies the cinematic color grade and gentle smart zoom, transcribes speech with the installed local Faster Whisper model, and burns word-by-word captions into the final video. It also saves editable captions to `OUTPUT/final-auto-edit-captions.ass`.

The selected music file from `MB/` is mixed under the original audio. Sanctus selects Tagalog transcription; Dramatic Background selects English transcription. Tagalog uses Faster Whisper's multilingual `base` model and may download it on first use. The first image in `IMAGES/` is used when present. Do not claim music or an image overlay was added unless the pipeline report says it was.

Do not edit or delete source videos. If the pipeline fails, report the failing step and its error instead of presenting an older output as the new result. After success, report the output path and summarize the steps completed.
