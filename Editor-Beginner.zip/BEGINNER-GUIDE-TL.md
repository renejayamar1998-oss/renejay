# Mabilisang Gabay (Beginner)

Ito ang source files ng Editor. Kailangan ng internet sa unang setup para ma-install ang mga kailangan nitong tools.

## Windows

1. I-install ang **Python 3.10+** at **Node.js 18+**.
2. I-extract ang ZIP.
3. Buksan ang na-extract na `Editor-Beginner` folder.
4. I-right-click sa loob ng folder at piliin ang **Open in Terminal**.
5. Patakbuhin:
   ```powershell
   .\setup.ps1
   ```
   Kung magtanong kung ida-download ang FFmpeg, pindutin ang `y` at Enter. Malaki ang download nito.
6. Ilagay ang sarili mong video clips sa `INPUT` folder.
7. Buksan ang folder sa Claude Code at patakbuhin ang `/Editor`. Maaari ring patakbuhin sa terminal:
   ```powershell
   .\.venv\Scripts\python.exe auto_edit.py
   ```
8. Lalabas ang tapos na video sa `OUTPUT`.

## Mahahalagang paalala

- Hindi kasama sa ZIP ang mga video, musika, logo, sound effects, o natapos na video mula sa orihinal na folder. Magdagdag lamang ng sarili mong files at tiyaking may pahintulot kang gamitin ang mga ito.
- Ang `setup.ps1` ay pang-isahang setup sa bawat computer. Kailangan ng internet at maaaring mag-download ng humigit-kumulang 110 MB na FFmpeg.
- Basahin ang `README.md` para sa macOS/Linux, opsyon, at dagdag na detalye.
