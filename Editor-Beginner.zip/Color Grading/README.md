Use this folder for color-grading reference files or custom presets.

The editor should inspect the video and choose only the grading that fits its lighting, skin tones, mood, and subject. Do not apply every preset or stack multiple looks by default. Available built-in presets include cinematic, warm, cool, moody, vivid, and black-and-white. Reference files placed here can guide a suitable grade; they are not all applied automatically.
